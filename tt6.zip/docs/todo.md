Todo
-

- readme
- comment all methods
- test every single public method
- integration testing
- style