package cs3500.threetrios.test.model.unit;

import cs3500.threetrios.model2.PossibleNewRef;
import org.junit.Test;

public class TestRefereeUnit {
}
