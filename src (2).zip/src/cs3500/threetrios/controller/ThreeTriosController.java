package cs3500.threetrios.controller;

/**
 * To control the flow of the game and handle input and output.
 */
public interface ThreeTriosController {

}
