package cs3500.threetrios.publictests.model;

/**
 * Tests for the model.
 */
public class TestDisconnectedLargeFullGame {
}
