package cs3500.threetrios.view;

public class ViewGUI implements View {
  @Override
  public void render() {

  }

}
