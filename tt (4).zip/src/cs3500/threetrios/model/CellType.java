package cs3500.threetrios.model;

public enum CellType {
  HOLE, CARD
}
