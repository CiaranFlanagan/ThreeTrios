package cs3500.threetrios;

import java.io.File;

/**
 * A class to hold the paths to the test files.
 */
public class TestFiles {
  public static File GRID1 = new File("./test/grid1.txt");
  public static File CARDCONFIG1 = new File("./test/cardConfig1.txt");
}
