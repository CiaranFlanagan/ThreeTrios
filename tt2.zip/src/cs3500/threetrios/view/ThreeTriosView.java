package cs3500.threetrios.view;

/**
 * Represents the view for the game of Three Trios.
 */
public interface ThreeTriosView {
  public String renderGame();
}
