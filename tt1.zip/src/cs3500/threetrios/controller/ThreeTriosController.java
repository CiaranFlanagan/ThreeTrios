package cs3500.threetrios.controller;

/**
 * to control the game of three trios and handle IO
 */
public interface ThreeTriosController {

}
