package cs3500.threetrios.view;

public interface ThreeTriosView {
  public String renderGame();
}
