package cs3500.threetrios.test;
import org.junit.Test;

public class TestUtils {


  @Test
  public void testAssertWorks() {

  }


}