package cs3500.threetrios;

import java.io.File;

public class TestFiles {
  public static File grid1 = new File("./test/grid1.txt");
  public static File cardConfig1 = new File("./test/cardConfig1.txt");
}
