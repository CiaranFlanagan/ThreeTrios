package cs3500.threetrios.player;

/**
 * to represent the difficulty of a player playing threetrios.
 */
public enum Difficulty {
  EASY, MEDIUM, HARD, IMPOSSIBLE, UNKNOWN
}
