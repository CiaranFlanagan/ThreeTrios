- are default methods on interfaces fine. reasoning:
  grid cells have behavior
  they are value classes but still
  we only want referee's to
  mutate them and their cards
  so we are only shipping those methods
  with the referee for a single
  point of control. 
- those classes have public read methods
and package private write methods that
the interface sees and bundles in
the default methods

- what is the examples class from HW1?
that was examplar. is that same as test class with only public methods?

