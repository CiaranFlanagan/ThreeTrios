- [ ] handle clicks 
- [ ] test strategy 2 & 3
- [ ] style & java doc
- [ ] fix model method numFlips()
- [ ] implement strategy 4 & test



