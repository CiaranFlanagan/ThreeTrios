package cs3500.threetrios.model;


/**
 * Tests for the ThreeTriosModel class.
 */
public class TestModel {
// only test methods that are not public, so protected or package private

}

